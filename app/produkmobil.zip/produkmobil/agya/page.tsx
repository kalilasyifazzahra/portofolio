
export default function Page() {
  return (
    <div className="text-center">
      <h1>ini mobil agya</h1>
    </div>
  )
}

