export default function Page() {
  return (
    <div className="text-center">
      <h1>ini listrik</h1>
    </div>
  )
}
