export default function Page() {
  return (
    <div className="text-center">
      <h1>ini roda</h1>
    </div>
  )
}
