export default function Page() {
  return (
    <div className="text-center">
      <h1>ini mobil roda empat</h1>
    </div>
  )
}
