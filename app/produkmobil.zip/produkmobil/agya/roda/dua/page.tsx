export default function Page() {
  return (
    <div className="text-center">
      <h1>ini motor bukan mobil</h1>
    </div>
  )
}
