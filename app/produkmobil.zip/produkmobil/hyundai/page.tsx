export default function Page() {
  return (
    <div className="text-center">
      <h1>ini hyundai</h1>
    </div>
  )
}
