export default function Page() {
  return (
    <div className="text-center">
      <h1>ini toyota</h1>
    </div>
  )
}
